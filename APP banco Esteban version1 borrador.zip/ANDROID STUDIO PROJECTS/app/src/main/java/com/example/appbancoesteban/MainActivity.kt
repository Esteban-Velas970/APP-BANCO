package com.example.appbancoesteban

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.appbancoesteban.ui.theme.APPBancoEstebanTheme
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            APPBancoEstebanTheme {
                var currentScreen by remember { mutableStateOf("inicio") }

                if (currentScreen == "inicio") {
                    InicioApp(onRegistrarClick = { currentScreen = "registro" })
                } else {
                    InicioSesion(onVolverClick = { currentScreen = "inicio" })
                }
            }
        }
    }
}
@Composable
fun InicioApp(onRegistrarClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE3F2FD)), // Azul medio clarito consistente
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Bienvenido a",
            fontSize = 20.sp,
            color = Color(0xFF1976D2)
        )
        Text(
            text = "Esteban970 Bank´s",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1976D2)
        )

        Spacer(modifier = Modifier.height(40.dp))

        Button(
            onClick = { /* Pendiente: Funcionalidad de inicio de sesión */ },
            modifier = Modifier.fillMaxWidth(0.8f)
        ) {
            Text("Iniciar Sesión")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { onRegistrarClick() },
            modifier = Modifier.fillMaxWidth(0.8f)
        ) {
            Text("Registrar una Nueva Cuenta")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewAppbancoEsteban() {
    APPBancoEstebanTheme {
        InicioApp(onRegistrarClick = {})
    }
}
